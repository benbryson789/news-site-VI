const login = (credentialsObject) => {
}

export default {
  login: login
}
